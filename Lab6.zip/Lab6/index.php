<?php
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
    /* po tym komentarzu będzie kod do dynamicznego ładowania stron */
    if ($_GET['idp'] == ''){
        if (file_exists('html/glowna.html'))
            $strona = 'html/glowna.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'historia'){
        if (file_exists('html/historia.html'))
            $strona = 'html/historia.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'kontakt'){
        if (file_exists('html/kontakt.html'))
            $strona = 'html/kontakt.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'pilkarze'){
        if (file_exists('html/pilkarze.html'))
            $strona = 'html/pilkarze.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'rekordy'){
        if (file_exists('html/rekordy.html'))
            $strona = 'html/rekordy.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'stadiony'){
        if (file_exists('html/stadiony.html'))
            $strona = 'html/stadiony.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'zadania'){
        if (file_exists('html/zadania.html'))
            $strona = 'html/zadania.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'zasady'){
        if (file_exists('html/zasady.html'))
            $strona = 'html/zasady.html';
        else $strona = 'html/404.html';
    }
    if ($_GET['idp'] == 'filmy'){
        if (file_exists('html/filmy.html'))
            $strona = 'html/filmy.html';
        else $strona = 'html/404.html';
    }
?>
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8"/>
    <meta http-equiv="Content-Language" content="pl"/>
    <meta name="Author" content="Michał Ziółkowski"/>
    <title>Moje hobby to piłka nożna</title>
    <link rel="stylesheet" href="css/style.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/kolorujtlo.js" type="text/javascript"></script>
	<script src="js/timedate.js" type="text/javascript"></script>
</head>
<body onload="startClock()">
    <div class="kontener">
        <table>
            <tr>
                <td>
                    <div class="naglowek">
                        <h1>Strona główna</h1></br>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div id="menu">
                        <div id="wybor2"><a href="?idp=zasady">Zasady gry</a></div>
                        <div class="wybor"><a href="?idp=pilkarze">Najlepsi piłkarze na świecie</a></div>
                        <div class="wybor"><a href="?idp=stadiony">Największe stadiony świata</a></div>
                        <div class="wybor"><a href="?idp=rekordy">Rekordy w piłce nożnej</a></div>
                        <div class="wybor"><a href="?idp=historia">Historia piłki nożnej</a></div>
						<div class="wybor"><a href="?idp=kontakt">Kontakt</a></div>
						<div class="wybor"><a href="?idp=zadania">Zadania</a></div>
                        <div class="wybor"><a href="?idp=filmy">Filmy</a></div>
                        <div class="wybor"><a href="?idp=glowna">Główna</a></div>
                    </div>
                </td>
            </tr>
            <tr>
                <?php
                    include($strona);
                ?>
            </tr>
            <tr>
                <td>

                </td>
            </tr>
        </table>
    </div>
	        <div class="stopka">
				Autor: Michał Ziółkowski</br>
            </div>
 <?php
    $nr_indeksu = '162625';
    $nrGrupy = '3';
    echo ('<b>Autor: Michał Ziółkowski ' .$nr_indeksu. ' grupa ' .$nrGrupy. ' <br /><br /></b>');
?>
</body>



</html>