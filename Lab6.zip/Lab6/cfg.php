<?php
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $baza = 'moja_strona';

    $link = mysqli_connect($dbhost, $dbuser, $dbpass);
    if (!$link) echo('<b> przerwano połączenie');
    if (!mysqli_select_db($baza)) echo ('nie wybrano bazy');