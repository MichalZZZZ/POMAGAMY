var x = false;
var zmienna = 0;

function zmien (entryform, from, to)
{
	convertfrom = from.selectedIndex;
	convertto = to.selectedIndex;
	entryform.display.value = (entryform.input.value * from[convertform].value / to[convertto].value);
}

function dodaj (input, character)
{
	if((character=='.' && zmienna=="0") || character!='.')
	{
		(input.value == "" || input.value == "0") ? input.value = character : input.value += character
		zmien(input.form,input.form.measure1,input.form.measure2)
		x = true;
		if (character=='.')
		{
			zmienna = 1;
		}
	}
}

function otworz()
{
	window.open("", "Display window", "toolbar=no,directories=no,menubar=no");
}

function wyczysc (form)
{
	form.input.value = 0;
	form.display.value = 0;
	zmienna = 0;
}

function zmienKolor(hexNumber)
{
	document.bgColor = hexNumber
}