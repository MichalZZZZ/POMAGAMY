function gettheDate()
{
	dzisiaj = new Date();
	data = "" + (dzisiaj.getMonth()+1)+" / "+ dzisiaj.getDate() + " / " +(dzisiaj.getYear()-100);
	document.getElementById("data").innerHTML = data;
}

var zegar = null;
var czasstart = false;

function stopClock()
{
	if(czasstart)
		clearTimeout(zegar);
	czasstart = false;
}

function startClock()
{
	stopClock();
	gettheDate()
	showtime();
}

function showtime()
{
	var teraz = new Date();
	var godziny = teraz.getHours();
	var minuty = teraz.getMinutes();
	var sekundy = teraz.getSeconds();
	var timeValue = "" + ((godziny >12) ? godziny -12 :godziny)
	timeValue += ((minuty < 10) ? ":0" : ":") + minuty
	timeValue += ((sekundy < 10) ? ":0" : ":") + sekundy
	timeValue += (godziny >= 12) ? " P.M." : " A.M."
	document.getElementById("zegarek").innerHTML = timeValue;
	zegar = setTimeout("showtime()",1000);
	czasstart = true;
}